#ifndef Py_INTERNAL_IMPORT_H
#define Py_INTERNAL_IMPORT_H

extern const char *_Py_CheckHashBasedPycsMode;

#endif
